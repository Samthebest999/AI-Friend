import wget
import os
from gtts import gTTS
import speech_recognition as sr
from playsound import playsound
